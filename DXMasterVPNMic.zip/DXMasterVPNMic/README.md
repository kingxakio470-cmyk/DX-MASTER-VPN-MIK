# DX MASTER – VPN Mic (Messenger Volume Booster)

1. Create a new GitHub repo and upload ALL these files (keep the folder structure, incl. `.github`).
2. Open the **Actions** tab -> "Build DX MASTER APK" -> wait for it to finish.
3. Download the **DX-MASTER-APK** artifact -> unzip -> install `app-debug.apk`.

Usage: Login on Facebook inside the app -> it opens Messenger automatically -> start a call ->
use the DX MASTER panel on the right side (+ / - / slider / ON-OFF) to boost your mic.
